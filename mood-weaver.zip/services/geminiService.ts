/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const CHARACTER_PROMPT_TEMPLATE = `
Generate a short, seamless, looping 2D animated video of a character named Wisp performing an action or expressing a feeling.

**Character Description:**
*   **Name:** Wisp
*   **Appearance:** A small, simple character with a full body. Its body is soft and pear-shaped, with two short, stump-like legs for standing or walking. Its form is solid but squishy.
*   **Face:** Only has two simple, expressive, black dot eyes. It has no mouth or arms. Emotion and action are conveyed through the shape of its body and eyes.
*   **Style:** Minimalist, clean, and cute. Use soft shading and no hard outlines. The style should be similar to modern animated educational videos (e.g., Psych2go).
*   **Background:** Choose a simple, non-distracting background that complements the mood from one of the following styles: a soft two-color gradient, a minimalist repeating pattern (like polka dots or waves), or a very simple scene (like a floor and a wall, or a patch of grass). The focus must remain on Wisp.
*   **Format:** 9:16 aspect ratio, suitable for social media shorts.

**Animation Modifiers:**
*   **Speed:** {SPEED_MODIFIER}
*   **Length:** {LENGTH_MODIFIER}

**Task:**
Create a short, looping animation of Wisp: **{USER_PROMPT}**.

The final video should be a high-quality, centered shot of Wisp.
`;

const wait = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

const SPEED_MAP: Record<string, string> = {
    'slo-mo': 'The animation should be in slow-motion, emphasizing the movement.',
    'normal': 'The animation should be at a normal, natural pace.',
    'fast': 'The animation should be quick and energetic.'
};

const LENGTH_MAP: Record<string, string> = {
    'short': 'The loop should be very short and simple (e.g., 2-3 seconds).',
    'medium': 'The loop should be slightly longer and more detailed (e.g., 4-5 seconds).'
};


/**
 * Generates an animation of the character "Wisp" based on a user-provided prompt.
 * @param userPrompt The action or expression for the character.
 * @param speed The desired speed of the animation ('slo-mo', 'normal', 'fast').
 * @param length The desired length of the animation loop ('short', 'medium').
 * @param onStatusUpdate A callback to provide real-time status updates to the UI.
 * @returns A promise that resolves to a browser-friendly object URL for the generated MP4 video.
 */
export async function generateCharacterAnimation(
    userPrompt: string,
    speed: string,
    length: string,
    onStatusUpdate: (status: string) => void
): Promise<string> {

    const speedModifier = SPEED_MAP[speed] || SPEED_MAP['normal'];
    const lengthModifier = LENGTH_MAP[length] || LENGTH_MAP['short'];

    const fullPrompt = CHARACTER_PROMPT_TEMPLATE
        .replace('{USER_PROMPT}', userPrompt)
        .replace('{SPEED_MODIFIER}', speedModifier)
        .replace('{LENGTH_MODIFIER}', lengthModifier);

    try {
        onStatusUpdate("Sending request to the animation studio...");
        let operation = await ai.models.generateVideos({
            model: 'veo-2.0-generate-001',
            prompt: fullPrompt,
            config: {
                numberOfVideos: 1
            }
        });
        
        onStatusUpdate("Wisp's animation is in the queue...");
        
        // Poll for the result
        while (!operation.done) {
            await wait(5000); // Wait 5 seconds between checks
            onStatusUpdate("Checking on the animation's progress...");
            operation = await ai.operations.getVideosOperation({ operation: operation });
        }

        onStatusUpdate("Finalizing the video...");
        const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;

        if (!downloadLink) {
             console.error("API operation finished but did not return a video URI:", operation);
             throw new Error("The AI model finished but failed to provide a video link. Please try again.");
        }

        onStatusUpdate("Downloading the final cut...");
        // The response.body contains the MP4 bytes. You must append an API key when fetching from the download link.
        const response = await fetch(`${downloadLink}&key=${API_KEY}`);
        
        if (!response.ok) {
            throw new Error(`Failed to download video: ${response.statusText}`);
        }

        const videoBlob = await response.blob();
        
        return URL.createObjectURL(videoBlob);

    } catch (error) {
        console.error("Error calling Gemini API:", error);
        const errorMessage = error instanceof Error ? error.message : "An unknown error occurred during animation generation.";
        throw new Error(`The AI model failed to create an animation. Details: ${errorMessage}`);
    }
}
