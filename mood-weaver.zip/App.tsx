/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { generateCharacterAnimation } from './services/geminiService';
import Footer from './components/Footer';

// A more dynamic placeholder for Wisp, with lofi-inspired idle animations.
const WispPlaceholder = () => {
    // Randomizing durations for a more organic, less robotic feel
    const swayDuration = 12 + Math.random() * 4; // 12-16s
    const bobDuration = 8 + Math.random() * 4; // 8-12s
    const driftDuration = 18 + Math.random() * 6; // 18-24s
    const eyeDriftXDuration = 9 + Math.random() * 4;
    const eyeDriftYDuration = 11 + Math.random() * 4;

    return (
        <motion.div
            className="drop-shadow-[0_0_12px_rgba(237,233,254,0.4)]"
            animate={{
                y: [0, -6, 2, -4, 0], // More complex bobbing
                rotate: [-2.5, 2, -1.5, 1, -2.5], // More complex swaying
                x: [0, 4, -3, 2, 0], // Gentle side-to-side drift
            }}
            transition={{
                y: { duration: bobDuration, repeat: Infinity, ease: "easeInOut", repeatType: "mirror" },
                rotate: { duration: swayDuration, repeat: Infinity, ease: "easeInOut", repeatType: "mirror" },
                x: { duration: driftDuration, repeat: Infinity, ease: "easeInOut", repeatType: "mirror" },
            }}
        >
            <svg width="200" height="200" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                {/* Body with subtle breathing animation */}
                <motion.path
                    d="M25 90 C 15 90, 10 70, 20 45 C 30 15, 70 15, 80 45 C 90 70, 85 90, 75 90 Z"
                    fill="url(#wisp-gradient)"
                    animate={{ scale: [1, 1.02, 1, 1.01, 1] }}
                    transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", repeatType: "mirror" }}
                />
                
                {/* Blinking and drifting eyes with desynchronized animations */}
                <g>
                    <motion.circle
                        cx="40" cy="50" r="3" fill="#1E293B" // Dark slate color for eyes
                        animate={{
                            scaleY: [1, 1, 0.1, 1],
                            x: [0, -1, 1, 0, 2, 0],
                            y: [0, 1.5, 0, -1, 0],
                        }}
                        transition={{
                            scaleY: { duration: 4.5, repeat: Infinity, ease: "easeInOut", times: [0, 0.95, 0.98, 1], delay: 0.2 },
                            x: { duration: eyeDriftXDuration, repeat: Infinity, ease: "easeInOut", repeatType: "mirror" },
                            y: { duration: eyeDriftYDuration, repeat: Infinity, ease: "easeInOut", repeatType: "mirror", delay: 1 },
                        }}
                    />
                    <motion.circle
                        cx="60" cy="50" r="3" fill="#1E293B"
                        animate={{
                            scaleY: [1, 1, 0.1, 1],
                            x: [0, 1.5, -1, 0.5, 0],
                            y: [0, -1, 1.2, -0.5, 0],
                        }}
                        transition={{
                            scaleY: { duration: 5.5, repeat: Infinity, ease: "easeInOut", times: [0, 0.95, 0.98, 1], delay: 1.1 },
                            x: { duration: eyeDriftXDuration + 2, repeat: Infinity, ease: "easeInOut", repeatType: "mirror" },
                            y: { duration: eyeDriftYDuration - 1.5, repeat: Infinity, ease: "easeInOut", repeatType: "mirror", delay: 0.5 },
                        }}
                    />
                </g>

                <defs>
                    {/* A more luminous gradient for Wisp to pop against the dark background */}
                    <radialGradient id="wisp-gradient" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(50 50) rotate(90) scale(45)">
                        <stop stopColor="#EDE9FE"/>
                        <stop offset="1" stopColor="#A78BFA"/>
                    </radialGradient>
                </defs>
            </svg>
        </motion.div>
    );
};

const LOADING_MESSAGES = [
    "Warming up the animation studio...",
    "Sketching Wisp's next move...",
    "Adding a splash of color...",
    "Rendering the animation frames...",
    "This can take a minute or two...",
    "Polishing the final cut...",
];

const MOOD_PALETTE = [
    "joyful", "sleepy", "curious", "dancing", "melting", "glowing"
];

const SPEED_OPTIONS = ['Slo-mo', 'Normal', 'Fast'];
const LENGTH_OPTIONS = ['Short', 'Medium'];

// FIX: Added App component and default export to resolve the module loading error.
const App = () => {
    const [prompt, setPrompt] = useState('A happy wisp dancing in the rain');
    const [mood, setMood] = useState('joyful');
    const [speed, setSpeed] = useState('Normal');
    const [length, setLength] = useState('Short');

    const [isLoading, setIsLoading] = useState(false);
    const [statusMessage, setStatusMessage] = useState('');
    const [videoUrl, setVideoUrl] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    const handleGenerate = async () => {
        if (isLoading || !prompt.trim()) return;

        setIsLoading(true);
        setError(null);
        if (videoUrl) {
            URL.revokeObjectURL(videoUrl);
            setVideoUrl(null);
        }

        try {
            const generatedUrl = await generateCharacterAnimation(
                prompt,
                speed.toLowerCase(),
                length.toLowerCase(),
                setStatusMessage
            );
            setVideoUrl(generatedUrl);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unexpected error occurred.');
        } finally {
            setIsLoading(false);
            setStatusMessage('');
        }
    };

    const handleMoodClick = (selectedMood: string) => {
        setMood(selectedMood);
        setPrompt(`A ${selectedMood} wisp...`);
    };

    return (
        <div className="bg-neutral-900 text-white min-h-screen font-sans flex flex-col">
            <main className="flex-grow flex flex-col items-center justify-center p-4 pt-16 sm:pt-20 pb-28">
                <div className="w-full max-w-5xl mx-auto flex flex-col lg:flex-row gap-8 items-center justify-center">

                    {/* Left Side: Video Display */}
                    <div className="w-full max-w-sm lg:w-1/3 flex-shrink-0">
                        <div
                            className="relative rounded-xl overflow-hidden shadow-2xl shadow-violet-500/20 bg-black aspect-[9/16]"
                        >
                            <AnimatePresence>
                                {isLoading && (
                                    <motion.div
                                        initial={{ opacity: 0 }}
                                        animate={{ opacity: 1 }}
                                        exit={{ opacity: 0 }}
                                        className="absolute inset-0 flex flex-col items-center justify-center z-10 p-4 bg-black/50"
                                    >
                                        <WispPlaceholder />
                                        <p className="mt-4 text-center text-sm text-neutral-400 animate-pulse">{statusMessage}</p>
                                    </motion.div>
                                )}
                            </AnimatePresence>

                            {videoUrl && !isLoading && (
                                <video
                                    src={videoUrl}
                                    autoPlay
                                    loop
                                    muted
                                    playsInline
                                    className="w-full h-full object-cover"
                                />
                            )}

                            {!videoUrl && !isLoading && (
                                <div className="absolute inset-0 flex flex-col items-center justify-center">
                                    <WispPlaceholder />
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Right Side: Controls */}
                    <div className="w-full lg:w-2/3 flex flex-col gap-6 p-6 rounded-xl bg-black/30 backdrop-blur-md border border-white/10">
                        <header>
                            <h1 className="text-3xl sm:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-500 to-yellow-400 font-permanent-marker">
                                Wisp Animator
                            </h1>
                            <p className="text-neutral-400 mt-2">
                                Bring Wisp to life! Describe a mood or action, and let AI create a unique animation for you.
                            </p>
                        </header>

                        {/* Prompt Input */}
                        <div className="flex flex-col gap-2">
                            <label htmlFor="prompt" className="font-medium text-neutral-300">Prompt</label>
                            <textarea
                                id="prompt"
                                value={prompt}
                                onChange={(e) => setPrompt(e.target.value)}
                                placeholder="e.g., A happy wisp dancing in the rain"
                                className="w-full p-3 rounded-md bg-neutral-800 border border-neutral-700 focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors duration-200 resize-none"
                                rows={3}
                                disabled={isLoading}
                            />
                        </div>

                        {/* Mood Palette */}
                        <div className="flex flex-col gap-2">
                            <label className="font-medium text-neutral-300">Or pick a mood...</label>
                            <div className="flex flex-wrap gap-2">
                                {MOOD_PALETTE.map((m) => (
                                    <button
                                        key={m}
                                        onClick={() => handleMoodClick(m)}
                                        disabled={isLoading}
                                        className={`px-3 py-1.5 text-sm rounded-full transition-colors duration-200 ${mood === m
                                                ? 'bg-purple-600 text-white'
                                                : 'bg-neutral-700 hover:bg-neutral-600 text-neutral-200'
                                            }`}
                                    >
                                        {m}
                                    </button>
                                ))}
                            </div>
                        </div>

                        {/* Settings */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div className="flex flex-col gap-2">
                                <label htmlFor="speed" className="font-medium text-neutral-300">Speed</label>
                                <select id="speed" value={speed} onChange={(e) => setSpeed(e.target.value)} disabled={isLoading} className="w-full p-2 rounded-md bg-neutral-800 border border-neutral-700 focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors duration-200 appearance-none bg-arrow-down bg-no-repeat bg-right">
                                    {SPEED_OPTIONS.map(s => <option key={s} value={s}>{s}</option>)}
                                </select>
                            </div>
                            <div className="flex flex-col gap-2">
                                <label htmlFor="length" className="font-medium text-neutral-300">Length</label>
                                <select id="length" value={length} onChange={(e) => setLength(e.target.value)} disabled={isLoading} className="w-full p-2 rounded-md bg-neutral-800 border border-neutral-700 focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors duration-200 appearance-none bg-arrow-down bg-no-repeat bg-right">
                                    {LENGTH_OPTIONS.map(l => <option key={l} value={l}>{l}</option>)}
                                </select>
                            </div>
                        </div>

                        {/* Generate Button */}
                        <button
                            onClick={handleGenerate}
                            disabled={isLoading || !prompt.trim()}
                            className="w-full mt-4 bg-yellow-400 text-black font-bold py-3 px-6 rounded-md text-lg transition-all duration-300 hover:bg-yellow-300 disabled:bg-neutral-700 disabled:text-neutral-500 disabled:cursor-not-allowed transform hover:scale-105 disabled:transform-none"
                        >
                            {isLoading ? 'Animating...' : 'Animate Wisp'}
                        </button>

                        {error && (
                            <motion.div
                                initial={{ opacity: 0, y: -10 }}
                                animate={{ opacity: 1, y: 0 }}
                                className="mt-4 p-3 bg-red-900/50 border border-red-500/50 text-red-200 rounded-md text-sm"
                            >
                                <p className="font-bold">Animation Failed</p>
                                <p>{error}</p>
                            </motion.div>
                        )}

                    </div>
                </div>
            </main>
            <Footer />
        </div>
    );
};

export default App;
